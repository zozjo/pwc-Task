<?php

$resuls=array();
if(isset($_POST['path']))
{
    $filename = $_POST['path'];
    if (file_exists($filename)) {
        unlink($filename);


        $resuls['status']='Done';
        echo json_encode($resuls);
    } else {
        $resuls['status']='file does not exist';
        echo json_encode($resuls);
    }
}



?>