<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if( $_SESSION['userIsSet']!=true &&  $_SESSION['userType']!=1){
    header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com/">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<link rel="canonical" href="pages-blank.html" />

	<title>Add New Complaint</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&amp;display=swap" rel="stylesheet">


  <link rel="stylesheet" href="css/dropzone.css">

<style>


</style>
</head>


<body data-theme="default" data-layout="fluid" data-sidebar="left">
 <input type="hidden" id="userID" name="userID" value="<?php echo $_SESSION['user_id'];?>">

	<div class="wrapper">
	<?php include 'navBar.php'; ?>

		<div class="main">
			<nav class="navbar navbar-expand navbar-light navbar-bg">
				<a class="sidebar-toggle d-flex">
					<i class="hamburger align-self-center"></i>
				</a>



				<div class="navbar-collapse collapse">
					<ul class="navbar-nav navbar-align">



						<li class="nav-item dropdown">


							<a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-bs-toggle="dropdown">
							 <span class="text-dark"><?php echo $_SESSION['user_name'] ?></span>
							</a>
							<div class="dropdown-menu dropdown-menu-end">

								<a class="dropdown-item" href="Logout.php"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-log-out align-middle me-2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
								Log out</a>
							</div>
						</li>
					</ul>
				</div>
			</nav>

			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Add new Complaint</h1>

					<div class="row">
						<div class="col-12">
							<div class="card">

								<div class="card-body">


									<label class="form-label w-100">Complaint Title</label>
											<input id="title" class="form-control" placeholder="Complaint Title" type="text">
									<label class="form-label w-100">Complaint Description</label>
											<textarea class="form-control" id="Description" rows="6" placeholder="Complaint Description"></textarea>
									<label class="form-label w-100">Complaint priority</label>

										<select class="form-control choices-single" id="priority">


											</select>
														<hr>

											<label class="form-label w-100">Complaint additional info</label>
											<div class="row">
											 		<label class="col-md-4 form-check form-check-inline">
											<input class="form-check-input" type="checkbox"  id="addImage" value="option1">
											<span class="form-check-label">
												add Complaint image

											</span>
										</label>
										<label class="col-md-4 form-check form-check-inline" >
											<input class="form-check-input" type="checkbox" id="notification"  value="option1" checked>
											<span class="form-check-label " >
												Tell me when updating

											</span>
										</label>


											</div>




<br>
									<div class="w-100 showimage" style="display: none;">
											<label class="form-label w-100">Complaint Images</label>

											<form class="dropzone" id="file_upload"></form>
											      <button id="upload_btn" class="btn btn-primary m-t-20 btn-github">Upload</button>
									<div class=" row " id="Images">
										</div>





										</div>
									<div class=" w-100 ">
								   <a class="btn btn-primary m-t-20 btn-github" href="index.php">Cancel</a>

									<button id="send" class="btn btn-primary m-t-20 btn-github" style="    float: right;">Send</button>
										</div>
								</div>
</div>
							</div>
						</div>
					</div>


			</main>


		</div>
	</div>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/10.13.0/sweetalert2.all.js" integrity="sha512-xyQB/ddHP6Oc0QtRFlyVsnBAOJhlxhLin3LXIjw3Ho9RnjppbCJOeb0OUXQ5HgIijMnzNxuCElb5FLkZLN+SSg==" crossorigin="anonymous"></script>

	<script src="js/app.js"></script>
	  <script type="text/javascript" src="js/dropzone.js"></script>

	<script src="js/AddComplaint.js"></script>

<script>

</script>



</body>


</html>