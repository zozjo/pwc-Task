<?php

$listImage=array();
  if($_FILES['file']['name'] != ''){

  	$file_names = '';

  	$total = count($_FILES['file']['name']);

  	for($i=0; $i<$total; $i++){
  		$filename = $_FILES['file']['name'][$i]; // Get the Uploaded file Name.
  		$extension = pathinfo($filename,PATHINFO_EXTENSION); //Get the Extension of uploded file

  		$valid_extensions = array("png","jpg","jpeg");

  		if(in_array($extension, $valid_extensions)){ // check if upload file is a valid image file.
  			$new_name = rand() . ".". $extension;
  			$path = "assets/ComplaintImage/" . $new_name;

  			move_uploaded_file($_FILES['file']['tmp_name'][$i], $path);

  			$file_names .= $new_name . " , ";

			$listImage['image'][]=$path;
  		}
  	}
	if($listImage['image'] != null){
		 $listImage['status']="done";
	}else{
				 $listImage['status']="false";

	}
    echo json_encode($listImage);

  }

?>
