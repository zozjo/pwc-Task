const change = src => {
            document.getElementById('main').src = src
        }
const queryString = window.location.search;

const urlParams = new URLSearchParams(queryString);
const ComplaintID = urlParams.get('ComplaintID');

$.ajax({
	 method: "POST",
	  url: "admin/api/Server/server.php",
	  data: {
			action   : "getComplaintByID",
			complaint_id:ComplaintID
	  	}

	}).done(function( data ) {
		responseData = JSON.parse(data);

		if(responseData.status=="success"){

			var Complaint_Info=responseData.body[0];


$(".Complaint_Title").text(Complaint_Info.complaint_title)
$(".Complaint_Body").text(Complaint_Info.complaint_body)
$("#date").text(Complaint_Info.create_at)
$("#Priority").text(Complaint_Info.priority_name)
$("#Status").text(Complaint_Info.status_name)

if(Complaint_Info.image.length>0)
	{
		$("#main").attr("src",Complaint_Info.image[0]['complaint_images'])
	 for(var i = 0; i < Complaint_Info.image.length; i++) {



		    var Image='<div class=" side_view col-6 col-md-6 col-lg-6">'
               +' <img class="demo cursor"  onclick="change(this.src)"src="'+Complaint_Info.image[i]['complaint_images']+'" style="width:100%"  alt="">'
            +'</div>';
		    $("#ImageRow").append(Image)
		}
	}
			console.log(responseData)
		}else{
			 window.location = "pages-404.html";
		}



	});