$.ajax({
	 method: "POST",
	  url: "admin/api/Server/server.php",
	  data: {
			action   : "getUsersComplaint",
			complaint_user_id:$("#userID").val(),
	  	}

	}).done(function( data ) {
		ComplaintList = JSON.parse(data);
		console.log(ComplaintList)
		if(ComplaintList.status=="success")
			{
			for(var i = 0; i < ComplaintList.body.length; i++) {
			    var My_Complaint = ComplaintList.body[i];
			    var Complaint="";

			    Priority='<div class="col-12 col-md-6 col-lg-4">'
				+'<div class="card">'
				+'<img class="card-img-top" src="'+My_Complaint.image+'" alt="Complaint Image">'
				+'<div class="card-header">'
				+'<h5 class="card-title mb-0">'+My_Complaint.complaint_title+'</h5>'
				+'</div>'
				+'<div class="card-body demo-2">'+My_Complaint.complaint_body+'</p>'
			    +'<ul class="list-group list-group-flush">'
			    +'<li class="list-group-item"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-clock align-middle me-2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>'+My_Complaint.create_at+'</li>'
			    +'<li class="list-group-item"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit align-middle me-2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>Status: '+My_Complaint.status_name+'</li>'
			    +'<li class="list-group-item"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bar-chart align-middle me-2"><line x1="12" y1="20" x2="12" y2="10"></line><line x1="18" y1="20" x2="18" y2="4"></line><line x1="6" y1="20" x2="6" y2="16"></line></svg>Priority: '+My_Complaint.priority_name+'</li>'
			    +'</ul><br>'
			    +'<a href="Complaint.php?ComplaintID='+My_Complaint.complaint_id+'" class="btn mb-1 btn-github">View</a>'
			    +'</div>'
			    +'</div>'
			    +'</div>';


			$('#My_Complaint').append(Priority);
		 }
			}


	});