var ImageList = [];
var addImage=0;
var notification=1;
$.ajax({
	 method: "POST",
	  url: "admin/api/Server/server.php",
	  data: {
			action   : "getPriority"
	  	}

	}).done(function( data ) {
		PriorityList = JSON.parse(data);
		 for(var i = 0; i < PriorityList.body.length; i++) {
			    var obj = PriorityList.body[i];


			    Priority='<option value="'+obj.priority_id+'">'+obj.priority_name+'</option>';

			$('.choices-single').append(Priority);
		 }
		 new Choices(document.querySelector(".choices-single"));

	});

$('#addImage').click(function(){
    if($(this).prop("checked") == true){
    	addImage=1;
    	 $(".showimage").css("display","flow-root");
    }
    else if($(this).prop("checked") == false){
    	 addImage=0;
        $(".showimage").css("display","none");
    }
});
$('#notification').click(function(){
    if($(this).prop("checked") == true){
    	notification=1;

    }
    else if($(this).prop("checked") == false){
    	notification=0;
    }
});
$('#send').click(function(){
   var title=$("#title").val();
   var Description=$("#Description").val();
   var priority=$("#priority").val();
   if(title==""){
		return Swal.fire({
			  icon: 'error',
			  title: 'Oops...',
			  text: 'Title is required!',
			})
		}
   if(Description==""){
		return Swal.fire({
			  icon: 'error',
			  title: 'Oops...',
			  text: 'Description is required!',
			})
		}
   if(addImage){
	   if(ImageList=== undefined ||ImageList.length == 0)
		{
		   return Swal.fire({
				  icon: 'error',
				  title: 'Oops...',
				  text: "You don't add any image plese upolde one or unselect option!",
				})
		}
   }
   $.ajax({
		 method: "POST",
		  url: "admin/api/Server/server.php",
		  data: {
				action   : "addComplaint",
				complaint_user_id:$("#userID").val(),
				title:title,
				Description:Description,
				addImage:addImage,
				status_priority_id:$("#priority").val(),
				notification:notification,
				imageList:ImageList


		  	}

		}).done(function( data ) {
			 var responseData= JSON.parse(data);
				console.log(responseData);
					if(responseData.status=="success"){

						Swal.fire({
							  icon: 'success',
							  title: 'Done...',
							  text: "You'r complaint submit successfully ",
							}).then((result) => {
							 window.location = "index.php";
						 })


					}

		});


});


Dropzone.autoDiscover = false;

    var myDropzone = new Dropzone("#file_upload", {
      url: "upload.php",
      parallelUploads: 3,
      uploadMultiple: true,
      acceptedFiles: '.png,.jpg,.jpeg',
      autoProcessQueue: false,
      success: function(file,response){
		 var itemImage= JSON.parse(response);
        if(itemImage.status == 'done'){

        	for(var i=0;i<itemImage.image.length;i++)
        		{
        		var a = ImageList.indexOf(itemImage.image[i]);
        		if(a == -1){
        			ImageList.push(itemImage.image[i]);
        		}


        		}


        }else{
          $('#content').append('<div class="message error">Images Can\'t Uploaded.</div>');
        }
      }
    });

    $('#upload_btn').click(function(){
      myDropzone.processQueue();
    });
	myDropzone.on("complete", function(file) {
  myDropzone.removeFile(file);
	$("#Images").empty();
	myFunction();
});



	function myFunction() {

    	for(var i=0;i<ImageList.length;i++)
		{
    		 $("#Images").append(
    				  '<div class="col-3 col-md-3 col-lg-6" style="    margin-top: 16px;" id="images'+i+'">'
    					+'<img alt=""style="height: 180px;    width: 100%;" src="'+ImageList[i]+'">'
    					+'<div class="deleteImage  delete btn-github" onclick="RemoveFile(\''+ImageList[i]+'\','+i+')">'
    					+'Delete'
    					+'</div>'
    					+'</div>'
    		  )

		}


	}
function RemoveFile(path,index){
	$.ajax({
		  method: "POST",
		  url: "RemoveFile.php",
		  data: {

	  			path   : path
		  	}

		}).done(function( data ) {
			 var jsonObj = JSON.parse(data);
			 if(jsonObj.status=="Done"){
				 ImageList.splice(index, 1);
				 $("#images"+index).hide();
			 }

		});
}
