
$("#LogIn").click(
function(){
	var email=$("#email").val();
	var password=$("#password").val();
	if(email==""){
	return	Swal.fire({
			  icon: 'error',
			  title: 'Oops...',
			  text: 'Email is required!',
			})
	}
if(password==""){
	return Swal.fire({
		  icon: 'error',
		  title: 'Oops...',
		  text: 'Password is required!',
		})
	}
if(!validateEmail(email)){
	return Swal.fire({
		  icon: 'error',
		  title: 'Oops...',
		  text: 'Email not valid!',
		})
}
$.ajax({
	 method: "POST",
	  url: "admin/api/Server/server.php",
	  data: {
			action   : "login",
			email:email.trim(),
			password:password,
	  	}

	}).done(function( data ) {
		 var responseData= JSON.parse(data);
		 console.log(responseData);
		 if(responseData.Status=="ERROR"){
			 return Swal.fire({
				  icon: 'error',
				  title: 'Oops...',
				  text: responseData.msg,
				})
		 }else{
			 $.ajax({
				 method: "POST",
				  url: "SetLogin.php",
				  data: {
					  SetUser:"SetUser",
					  userType:responseData.userType,
						  user_id:responseData.user_id,
						  user_name:responseData.user_name
				  	}

				}).done(function( data ) {
					 var responseData= JSON.parse(data);
					 window.location = responseData;

				});


		 }


	});
}

);
function validateEmail(email) {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}