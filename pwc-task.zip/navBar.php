<nav id="sidebar" class="sidebar">
   <div class="sidebar-content js-simplebar">
      <a class="sidebar-brand" href="index-2.html">
      <span class="align-middle">ABC Complaint system</span>
      </a>
      <ul class="sidebar-nav">
         <li class="sidebar-header">
            Pages
         </li>

         <li class="sidebar-item active">
            <a data-bs-target="#pages" data-bs-toggle="collapse" class="sidebar-link">
            <i class="align-middle" data-feather="layout"></i> <span class="align-middle">Complaint</span>
            </a>
            <ul id="pages" class="sidebar-dropdown list-unstyled collapse show" data-bs-parent="#sidebar">
               <li class="sidebar-item"><a class="sidebar-link" href="index.php">My Complaint</a></li>
                <li class="sidebar-item"><a class="sidebar-link" href="AddComplaint.php">Add new Complaint</a></li>


            </ul>
         </li>
</ul>
   </div>
</nav>