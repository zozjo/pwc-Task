<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (isset($_POST['SetUser']) && isset($_POST['userType']) && isset($_POST['user_id']) && isset($_POST['user_name']))
{

    $_SESSION['userIsSet']=true;
    $_SESSION['userType']=$_POST['userType'];
    $_SESSION['user_id']=$_POST['user_id'];
    $_SESSION['user_name']=$_POST['user_name'];
    if($_POST['userType']==1){
        echo json_encode('index.php');

    }
    else{
        echo json_encode('admin/index.php');

    }

}


?>