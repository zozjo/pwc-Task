<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class Sql {

    public $servername  = "localhost:3306";
    public $username    = "pwc-task";
    public $password    = "7i!v91Mq";
    public $db          = "pwc-task";
    public $conn;


    public function __construct() {

        try {
            $this->conn = new PDO("mysql:host=$this->servername;dbname=$this->db;charset=utf8", $this->username, $this->password);
            // set the PDO error mode to exception
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        } catch(PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
            die();
        }

    }


    /*
     * Simple Query
     *
     * Example
     * $sql->getJoin('product join category on product.category_id = category.id')
     *
     * */


    public function get($table, $where = '', $column = "*") {

        if($where != '')
            $where = " where ". $where;

            $stmt = $this->conn->prepare("SELECT $column FROM $table $where");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


    /*
     * Query with join
     *
     * Example
     * $sql->getJoin('product join category on product.category_id = category.id')
     *
     *
     * */
    public function getJoin($join, $where = '', $column = "*") {

        if($where != '')
            $where = " where ". $where;

            $stmt = $this->conn->prepare("SELECT $column FROM $join $where");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }



    /*
     * Insert Query
     *
     * Example
     *
     * $sql->insert('category', ["category_name" => 'test', "category_image" => 'test'])
     *
     * $data is array => the key equal column name and the value is the data you want to insert
     * */
    public function insert($table, $data) {

        if(count($data) == 0) {
            return "Invalid data";
        }

        try {

            $names      = [];
            $values     = '';
            $counter    = 0;

            foreach ($data as $key => $val) {
                if($counter != 0)
                    $values .= " ,";


                    $names  [] = $key;
                    $counter++;

                    if(is_numeric($val))
                        $values    .= $val;
                        else
                            $values    .= "'".$val."'";
            }

            $names = implode(",", $names);

            $sql = "INSERT
            INTO $table
            ($names)
            VALUES
            ($values)";
            // use exec() because no results are returned
            return $this->conn->exec($sql);
        } catch(PDOException $e) {
            return $sql . "<br>" . $e->getMessage();
        }
    }

    /*
     * delete Query
     *
     * Example
     * $sql->delete('category', 'id = 1')
     *
     * */

    public function delete($table, $where = '') {

        if($where != '')
            $where = " where ". $where;

            $stmt = $this->conn->prepare("delete FROM $table $where");
            return $stmt->execute();

    }
    public function subQurery($where = '') {


        //         if($where != '')
            //             $where = " where ". $where;

            $stmt = $this->conn->prepare("select b.*, (select sum(rate) / count(rate) from review where b.id = review.book_id) as total_rate from book b ");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);

    }

    /*
     * Insert Query
     *
     * Example
     *
     * $sql->update('category', ["category_name" => "tesssst"],'id = 1')
     *
     * $data is array => the key equal column name and the value is the data you want to update
     * */
    public function update($table, $data, $where = '') {

        if(count($data) == 0) {
            return "Invalid data";
        }

        if($where != '')
            $where = " where ". $where;

            try {

                $values     = '';
                $counter    = 0;

                foreach ($data as $key => $val) {
                    if($counter != 0)
                        $values .= " ,";

                        $counter++;
                        $values    .= $key ." = '".$val."'";
                }


                $sql = "UPDATE $table
                Set
                $values $where";
                // use exec() because no results are returned
                return $this->conn->exec($sql);
            } catch(PDOException $e) {
                return $sql . "<br>" . $e->getMessage();
            }
    }

    public function lastId () {

        return $this->conn->lastInsertId();

    }


}

// echo "<pre>";
// $sql = new Sql();
// print_r($sql->update('category', ["category_name" => "tesssst"],'id = 1'));




?>