<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include "sql.php";
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

if(isset($_POST['action']) == false)
    die( "Action is not defined" );

    $action = $_POST['action'];
    $appLap = new AppLap ();
    $appLap->$action();


class AppLap {
    private $data;
    private $file;
    private $query;
    private $encryptKey = "24525ashmoe462d";
    private $cipher     = "aes128";
    private $secret_iv  = "2223455223dsadhda";
    private $iv;


    public function __construct() {
        $this->query = new Sql();
        $this->data = $_POST;
        $this->file = $_FILES;
        $this->iv = substr(hash('sha256', $this->secret_iv), 0, 16);

        if(isset($this->data['user_id'])) {
            $this->data['user_id'] = $this->dencrypt($this->data['user_id']);
        }
        if(isset($this->data['complaint_user_id'])) {
            $this->data['complaint_user_id'] = $this->dencrypt($this->data['complaint_user_id']);
        }
        if(isset($this->data['status_priority_id'])) {
            $this->data['status_priority_id'] = $this->dencrypt($this->data['status_priority_id']);
        }




    }


    public function forgetpassword(){
        $result=array();
        $data = $this->query->get("users",
            "(email = '{$this->data['email']}') ");
        if($data != null)
        {
            $Token=$data[0]['user_token'];
            $RestToken=$this->encrypt($data[0]['user_id']);
            $url="https://pwc-task.meet-skype.com/ForgetPassword.php?Token=$Token&RestToken=$RestToken";
            $sendEmail=$this->sendEmail($this->data['email'],$url);
            if($sendEmail)
            {
                $result['status']="success";
            }
        }else{
            $result['status']="Error";
        }
        $this->sendBack($result);
    }
    public function sendEmail($email,$url){
        $result;
        $mail = new PHPMailer(true);

        try {
            //Server settings
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'meet-skype.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'info@meet-skype.com';                     //SMTP username
            $mail->Password   = '996100288@aA@';                               //SMTP password
            $mail->Port       = 25;                                    //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

            //Recipients
            $mail->setFrom('info@meet-skype.com', 'Forgot password');
            $mail->addAddress($email);     //Add a recipient

            //Attachments
            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'forgot password';
            $mail->Body    = 'We heard that you lost your ABC  password. Sorry about that!<br>

But don�t worry! You can use the following link to reset your password:<br>

<a href="'.$url.'">'.$url.'</a><br>


Thanks,<br>
The ABC Team';

            $mail->send();
            $result='true';
        } catch (Exception $e) {
            $result= "false";
        }
        return $result;
    }

    public function signup() {
        $msgBack=array();
        $this->emptyValidation($this->data);
        $msg = '';
        if (!filter_var($this->data['email'], FILTER_VALIDATE_EMAIL)) {
            $msg = "Invalid email format.";
        }


        if($msg != ''){
            $msgBack ['status'] = "ERROR";
            $msgBack ['msg'] = $msg;
            return $this->sendBack($msgBack);
        }
        if($this->checkUser()){
            $msgBack ['status'] = "ERROR";
            $msgBack ['msg']  = "This user already registered.";
            return $this->sendBack($msgBack);
        }

            $password   = md5($this->data['password']);
            $insert = [];
            $insert ["user_type"]               = 1;
            $insert ["email"]                   = $this->data['email'];
            $insert ["user_name"]               = $this->data['user_name'];
            $insert ["password"]                = $password;
            $insert ["user_token"]              = sha1(mt_rand(1, 90000) . 'SALT');;


            $res = $this->query->insert('users', $insert);
            $msg = [];
            if($res == 1){
                $msg ['status'] = "success";
                $msg ['UserId'] = $this->encrypt( $this->query->lastId());
    }
                else {
                    $msg ['status'] = "ERROR";
                    $msg ['msg'] = $res;
                }
                $this->sendBack($msg);

    }
    public function checkUser() {
        $data = $this->query->get("users","(email = '{$this->data['email']}')");
        if(count($data) > 0){
            return 1;
        }else{
            return 0;
        }
    }
    public function getPriority() {
        $ResultData=array();
        $data = $this->query->get("priority");
        if(count($data) > 0){

            for($i=0;$i<count($data);$i++){
                $data[$i]['priority_id']=$this->encrypt($data[$i]['priority_id']);
            }
            $ResultData['body']=$data;
            $ResultData['status'] = "success";

            $this->sendBack($ResultData);

        }else{
            $ResultData ['status'] = "ERROR";
            $ResultData ['msg'] = "No data available";
            $this->sendBack($ResultData);
        }
    }
    public function updateStatus(){
        $msg =array();
        $update=array();
        $update ["status_id"]          = $this->dencrypt($this->data['status_id']);
        $res = $this->query->update('complaint', $update, "complaint_id = '{$this->dencrypt($this->data['ComplaintID'])}'");
        $this->sendBack($this->dencrypt($this->data['ComplaintID']));
         if($res == 1)
             $msg ['status'] = "success";
             else {
                 $msg ['status'] = "ERROR";
                 $msg ['msg'] = $res;
             }
             $this->sendBack($msg);
    }
    public function addPriority() {
        $this->emptyValidation($this->data);
        $insert = [];
        $insert ["priority_name"] = $this->data['priority_name'];

        $res = $this->query->insert('priority', $insert);

        $msg = [];
        if($res == 1)
            $msg ['status'] = "success";
            else {
                $msg ['status'] = "ERROR";
                $msg ['msg'] = $res;
            }
            $this->sendBack($msg);
    }

    public function getCount() {
        $data=array();
        $data['1'] = $this->query->get("complaint","","count(*) as count");
        $data['2'] = $this->query->get("users","","count(*) as count");
        $this->sendBack($data);

    }
    public function getStatus() {
        $ResultData=array();
        $data = $this->query->get("status");
        if(count($data) > 0){

            for($i=0;$i<count($data);$i++){
                $data[$i]['status_id']=$this->encrypt($data[$i]['status_id']);
            }
            $ResultData['body']=$data;
            $ResultData['status'] = "success";

            $this->sendBack($ResultData);

        }else{
            $ResultData ['status'] = "ERROR";
            $ResultData ['msg'] = "No data available";
            $this->sendBack($ResultData);
        }
    }
    public function addStatus() {
        $insert = [];
        $insert ["status_name"] =$this->data['status_name'];


        $res = $this->query->insert('status', $insert);

        $msg = [];
        if($res == 1)
            $msg ['status'] = "success";
            else {
                $msg ['status'] = "ERROR";
                $msg ['msg'] = $res;
            }
            $this->sendBack($msg);
    }

    public function login() {

        $password   = md5($this->data['password']);

        $data = $this->query->get("users",
            "(email = '{$this->data['email']}') and password = '{$password}'");

        if(count($data) > 0) {
            $data[0]['user_id'] = $this->encrypt($data[0]['user_id']);
            $this->sendBack(["Status" => 'success', "user_name" => $data[0]['user_name'],"user_id" => $data[0]['user_id'],"userType" =>$data[0]['user_type']]);
        }else
            $this->sendBack(["Status" => 'ERROR', "msg" =>'Check your email and password Please.']);

    }
    public function getAllUsers(){
        $data = $this->query->get("users");
        $this->sendBack($data);
    }
    public function addComplaint() {
        $this->emptyValidation($this->data);
        $insert = [];
        $insert ["complaint_user_id"] =$this->data['complaint_user_id'];
        $insert ["status_id"] =0;
        $insert ["status_priority_id"] =$this->data['status_priority_id'];
        $insert ["complaint_title"] =$this->data['title'];
        $insert ["complaint_body"] =$this->data['Description'];
        $insert ["notification"] =$this->data['notification'];
        $res = $this->query->insert('complaint', $insert);
        $msg = [];
        if($res == 1){
            if($this->data['addImage']==1)
            {
                $this->addImageList($this->data['imageList'],$this->query->lastId());
            }
            $msg ['status'] = "success";
        }

            else {
                $msg ['status'] = "ERROR";
                $msg ['msg'] = $res;
            }
            $this->sendBack($msg);






    }
    public function getUsersComplaint() {
        $ResultData=array();
        $this->emptyValidation($this->data);
        $data = $this->query->getJoin("complaint join status on status.status_id=complaint.status_id join priority on priority.priority_id=complaint.status_priority_id","(complaint.complaint_user_id = '{$this->data['complaint_user_id']}')","complaint.complaint_id,complaint.create_at,complaint.complaint_title,complaint.complaint_body,priority.priority_name,status.status_name");

        if(count($data) > 0){

            for($i=0;$i<count($data);$i++){

                $data[$i]['image']=$this->getFitstImage($data[$i]['complaint_id']);
                $data[$i]['complaint_id']=$this->encrypt($data[$i]['complaint_id']);
            }
            $ResultData['body']=$data;
            $ResultData['status'] = "success";

            $this->sendBack($ResultData);

        }else{
            $ResultData ['status'] = "ERROR";
            $ResultData ['msg'] = "No data available";
            $this->sendBack($ResultData);
        }
    }
    public function getAllComplaint() {
        $ResultData=array();
        $this->emptyValidation($this->data);
        $data = $this->query->getJoin("complaint join users on users.user_id=complaint.complaint_user_id join  status on status.status_id=complaint.status_id join priority on priority.priority_id=complaint.status_priority_id","","complaint.complaint_id,complaint.create_at,complaint.complaint_title,complaint.complaint_body,priority.priority_name,status.status_name,users.user_name");

        if(count($data) > 0){

            for($i=0;$i<count($data);$i++){

                $data[$i]['image']=$this->getFitstImage($data[$i]['complaint_id']);
                $data[$i]['complaint_id']=$this->encrypt($data[$i]['complaint_id']);
            }
            $ResultData['body']=$data;
            $ResultData['status'] = "success";

            $this->sendBack($ResultData);

        }else{
            $ResultData ['status'] = "ERROR";
            $ResultData ['msg'] = "No data available";
            $this->sendBack($ResultData);
        }
    }
    public function getFitstImage($complaint_id){
        $data = $this->query->get("complaint_images",
            "(complaint_id = '{$complaint_id}')");
        if(count($data) > 0) {
            return $data[0]['complaint_images'];
        }else{
            return "assets/ComplaintImage/noImageAva.png";
        }
    }
    public function getComplaintByID() {
        $ResultData=array();
        $complaint_id=$this->dencrypt($this->data['complaint_id']);
        $this->emptyValidation($this->data);
        $data = $this->query->getJoin("complaint join status on status.status_id=complaint.status_id join priority on priority.priority_id=complaint.status_priority_id",
            "(complaint_id = '{$complaint_id}')",
        "complaint.create_at,complaint.complaint_title,complaint.complaint_body,priority.priority_name,status.status_name");

        if(count($data) > 0){

            for($i=0;$i<count($data);$i++){

                $data[$i]['image']=$this->getComplaintImage($complaint_id);
            }
            $ResultData['body']=$data;
            $ResultData['status'] = "success";

            $this->sendBack($ResultData);

        }else{
            $ResultData ['status'] = "ERROR";
            $ResultData ['msg'] = "No data available";
            $this->sendBack($ResultData);
        }
    }
    public function addImageList($ImageListArray,$lastID) {

    $arrayData=$ImageListArray;
    foreach ($arrayData as $value) {
        $insert = [];
        $insert ["complaint_images"] =$value;
        $insert ["complaint_id"] =$lastID;
         $this->query->insert('complaint_images', $insert);
    }
    }
    public function getComplaintImage($complaint_id){
        $data = $this->query->get("complaint_images",
            "(complaint_id = '{$complaint_id}')","complaint_images");
        if(count($data) > 0) {
            return $data;
        }else{
            return "assets/ComplaintImage/noImageAva.png";
        }
    }
    private function emptyValidation ($data){
        foreach ($data as $k => $v) {
            if($v == '')
                return $this->sendBack(['status' => "ERROR: this $k is required"]);
        }
    }


    private function sendBack($data) {
        echo json_encode($data);
        die();
    }

    private function encrypt ($text) {

        $text =  (openssl_encrypt($text, $this->cipher, $this->encryptKey, $options=0, $this->iv));
        return base64_encode($text);
    }

    private function dencrypt($text) {
        $text = base64_decode($text);
        $original_plaintext = openssl_decrypt($text, $this->cipher, $this->encryptKey, $options=0, $this->iv);
        return $original_plaintext;
    }


}


    ?>