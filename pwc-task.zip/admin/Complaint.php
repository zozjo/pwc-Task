<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if( $_SESSION['userIsSet']!=true &&  $_SESSION['userType']!=2){
    header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="preconnect" href="https://fonts.gstatic.com/">
      <link rel="shortcut icon" href="img/icons/icon-48x48.png" />
      <link rel="canonical" href="pages-blank.html" />
      <title>ABC | Complaint Details</title>
      <link href="css/app.css" rel="stylesheet">
      <link href="css/ComplaintSlider.css" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&amp;display=swap" rel="stylesheet">
   </head>
   <!--
      HOW TO USE:
      data-theme: default (default), dark, light
      data-layout: fluid (default), boxed
      data-sidebar: left (default), right
      -->
   <body data-theme="default" data-layout="fluid" data-sidebar="left">
      <div class="wrapper">
         <?php include 'navBar.php'; ?>
         <input type="hidden" id="userID" name="userID" value="<?php echo $_SESSION['user_id'];?>">
         <div class="main">
            <nav class="navbar navbar-expand navbar-light navbar-bg">
               <a class="sidebar-toggle d-flex">
               <i class="hamburger align-self-center"></i>
               </a>
               <div class="navbar-collapse collapse">
                  <ul class="navbar-nav navbar-align">
                     <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-bs-toggle="dropdown">
                        <span class="text-dark"><?php echo $_SESSION['user_name'] ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                           <a class="dropdown-item" href="Logout.php">
                              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-log-out align-middle me-2">
                                 <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                                 <polyline points="16 17 21 12 16 7"></polyline>
                                 <line x1="21" y1="12" x2="9" y2="12"></line>
                              </svg>
                              Log out
                           </a>
                        </div>
                     </li>
                  </ul>
               </div>
            </nav>
            <main class="content">
               <div class="container-fluid p-0">
                  <h1 class="h3 mb-3">Complaint details</h1>
              <a data-bs-toggle="modal" data-bs-target="#defaultModalPrimary" class="float-right btn btn-primary btn-github">Update Status</a>

                  <div class="row">
                     <div class="col-12">
                        <div class="">
                           <div class="card-body">
                              <div class="col-12 col-md-12 col-lg-12">
                                 <div class="card">
                                    <div class="card-header">
                                       <h5 class="card-title mb-0 Complaint_Title"></h5>
                                    </div>
                                    <div class="card-body">
                                    <p class="card-text Complaint_Body">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                    <ul class="list-group list-group-flush">
                                       <li class="list-group-item">
                                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-clock align-middle me-2">
                                             <circle cx="12" cy="12" r="10"></circle>
                                             <polyline points="12 6 12 12 16 14"></polyline>
                                          </svg>
                                          <span id="date"></span>
                                       </li>
                                       <li class="list-group-item">
                                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit align-middle me-2">
                                             <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                             <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                          </svg>
                                          Status: <span id="Status"></span>
                                       </li>
                                       <li class="list-group-item">
                                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bar-chart align-middle me-2">
                                             <line x1="12" y1="20" x2="12" y2="10"></line>
                                             <line x1="18" y1="20" x2="18" y2="4"></line>
                                             <line x1="6" y1="20" x2="6" y2="16"></line>
                                          </svg>
                                          Priority: <span id="Priority"></span>
                                       </li>
                                    </ul>
                                    </div>

                                 </div>
                              </div>
                              <h2 style="text-align:center">Complaint Image</h2>
                              <div class="main_view">
                                 <img src="" id="main" alt="IMAGE">
                              </div>
                              <div class="row" id="ImageRow">


                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
         </div>
         </main>
      </div>
      <div class="modal fade" id="defaultModalPrimary" tabindex="-1" role="dialog" aria-hidden="true">
										<div class="modal-dialog" role="document">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title">Update Status</h5>
													<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
												</div>
												<div class="modal-body m-3">
                									<div class="mb-3">
                										<select id="selec"class="form-control choices-single">
                										</select>
                									</div>			 									</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
													<button type="button" class="btn btn-primary btn-github" id="Save">Save changes</button>
												</div>
											</div>
										</div>
									</div>
      <script src="js/app.js"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      	<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/10.13.0/sweetalert2.all.js" integrity="sha512-xyQB/ddHP6Oc0QtRFlyVsnBAOJhlxhLin3LXIjw3Ho9RnjppbCJOeb0OUXQ5HgIijMnzNxuCElb5FLkZLN+SSg==" crossorigin="anonymous"></script>

      <script src="js/Complaint.js"></script>
   </body>
</html>