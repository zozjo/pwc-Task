$.ajax({
	 method: "POST",
	  url: "api/Server/server.php",
	  data: {
			action   : "getPriority"
	  	}

	}).done(function( data ) {
		PriorityList = JSON.parse(data);
		 for(var i = 0; i < PriorityList.body.length; i++) {
			    var obj = PriorityList.body[i];
				product='<tr>'
					+'<td>'+(i+1)+'</td>'
					+'<td>'+obj.priority_name+'</td>'

					+'</tr>'

					$('#userTableBody').append(product);
				 }
				 $("#datatables-reponsive").DataTable({
						responsive: true
					});
				});
$("#Save").click(function(){
	$.ajax({
		 method: "POST",
		  url: "api/Server/server.php",
		  data: {
				action   : "updateStatus",
				priority_name:$("#InputName").val()
		  	}

		}).done(function( data ) {
			location.reload();
		});

});