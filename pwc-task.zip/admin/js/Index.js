$.ajax({
	  method: "POST",
	  url: "api/Server/server.php",
	  data: {
			action   : "getAllComplaint"
	  	}

	}).done(function( data ) {
		 var jsonObj = JSON.parse(data);
		 console.log(jsonObj);
	 for(var i = 0; i < jsonObj.body.length; i++) {
		    var obj = jsonObj.body[i];

		product='<tr>'
		+'<td>'+(i+1)+'</td>'
		+'<td>'+obj.user_name+'</td>'
		+'<td>'+obj.create_at+'</td>'
		+'<td>'+obj.complaint_title+'</td>'
		+'<td>'+obj.complaint_body+'</td>'
		+'<td>'+obj.priority_name+'</td>'
		+'<td>'+obj.status_name+'</td>'
		+'<td><a href="Complaint.php?ComplaintID='+obj.complaint_id+'" class="btn mb-1 btn-github"><i class="align-middle fab my-1 "><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye align-middle me-2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg></i></button></td>'

		+'</tr>'

		$('#userTableBody').append(product);
	 }
	 $("#datatables-reponsive").DataTable({
			responsive: true
		});
	});
$.ajax({
	  method: "POST",
	  url: "api/Server/server.php",
	  data: {
			action   : "getCount"
	  	}

	}).done(function( data ) {
		 var jsonObj = JSON.parse(data);
		 console.log(jsonObj)
			$("#Count1").text(jsonObj[1][0]['count'])
			$("#Count2").text(jsonObj[2][0]['count'])


	});