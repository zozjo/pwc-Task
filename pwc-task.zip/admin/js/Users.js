$.ajax({
	  method: "POST",
	  url: "api/Server/server.php",
	  data: {
			action   : "getAllUsers"
	  	}

	}).done(function( data ) {
		 var jsonObj = JSON.parse(data);
		 console.log(jsonObj);
	 for(var i = 0; i < jsonObj.length; i++) {
		    var obj = jsonObj[i];

		   var User_type=obj.user_type==0?"Admin":"User"
		product='<tr>'
		+'<td>'+(i+1)+'</td>'
		+'<td>'+obj.user_name+'</td>'
		+'<td>'+obj.email+'</td>'
		+'<td>'+User_type+'</td>'
		+'</tr>'

		$('#userTableBody').append(product);
	 }
	 $("#datatables-reponsive").DataTable({
			responsive: true
		});
	});